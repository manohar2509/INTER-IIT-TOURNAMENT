<html>
<head>
    <style>
        body 
        {   
			background-image:url("background.jpg");
		    background-color:#ccccff;
            font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
            font-size: 150%;
        }
		.clear 
    {        
        clear:both;         
    }
		input[type=submit] {
  background-color: #80ff80;
  border: none;
  text-decoration: none;
  margin: 4px 2px;
}
input [type=text],select
{
	height:30px;
	border-radius:5px;
	padding-bottom: 3px;
	padding-left: 3px;
	margin-top:10px;
	border:1px solid black;
	
}
 input[type=submit]:hover{
		background-color: #eee;
	}
	input [type=text],select
{
	height:30px;
	width:150px;
	font-size:100%;
	border-radius:5px;
	padding-bottom: 3px;
	padding-left: 3px;
	margin-top:10px;
	border:1px solid black;
}
	#wrapper{
			width:500px;
			height:650px;
			margin:0 auto;
			border:5px solid  #66a3ff;
			border-radius:10px;
			
		}
		.clear 
    {        
        clear:both;         
    }
	.col-25 {
  font-size:medium;
  float: left;
  width: 40%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 60%;
  font-size:medium;
  margin-top: 6px;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
h1 {
	color:white;
  text-shadow: 5px 5px 4px blue;
  font-size:250%;
  
}

    </style>
</head>
    <body>
    <h1 style="text-align: center"> INTER IIT TOURNAMENT </h1>
        <form action='Resultsupdate.php' method='POST' style="text-align: center;">
		<div id="wrapper">
				For Men<br>
				<div class="row">
				<div class = "col-25"> <label for="rs" style="font-size:130%;"><b>Choose Your IIT for 1st:</b></label></div>
				<div class = "col-75">
                <select name="rs"id="iit"style="font-size:100%" >
				    <option value="madras">madras</option>
					<option value="delhi">delhi</option>
					<option value="bombay">bombay</option>
					<option value="kanpur">kanpur</option>
					<option value="kharagpur">kharagpur</option>
					<option value="roorke">roorke</option>
					<option value="guwahati">guwahati</option>
					<option value="hyderabad">hyderabad</option>
					<option value="indore">indore</option>
					<option value="varanasi">varanasi</option>
					<option value="dhanbad">dhanbad</option>
					<option value="bhuvaneswar">bhuvaneswar</option>
					<option value="gandhinagar">gandhinagar</option>
					<option value="ropar">ropar</option>
					<option value="patna">patna</option>
					<option value="mandi">mandi</option>
					<option value="jhodpur">jhodpur</option>
					<option value="tirupati">tirupati</option>
					<option value="bhilai">bhilai</option>
					<option value="goa">goa</option>
					<option value="jammu">jammu</option>
					<option value="dharwad">dharwad</option>
					<option value="palakkad">palakkad</option>
				</select><br></div>
				</div>
				<div class="row">
				<div class = "col-25"> <label for="rs1" style="font-size:130%;"><b>Choose Your IIT for 2nd:</b></label></div>
				<div class = "col-75">
				<select name="rs1"id="iit"style="font-size:100%" >
				    <option value="madras">madras</option>
					<option value="delhi">delhi</option>
					<option value="bombay">bombay</option>
					<option value="kanpur">kanpur</option>
					<option value="kharagpur">kharagpur</option>
					<option value="roorke">roorke</option>
					<option value="guwahati">guwahati</option>
					<option value="hyderabad">hyderabad</option>
					<option value="indore">indore</option>
					<option value="varanasi">varanasi</option>
					<option value="dhanbad">dhanbad</option>
					<option value="bhuvaneswar">bhuvaneswar</option>
					<option value="gandhinagar">gandhinagar</option>
					<option value="ropar">ropar</option>
					<option value="patna">patna</option>
					<option value="mandi">mandi</option>
					<option value="jhodpur">jhodpur</option>
					<option value="tirupati">tirupati</option>
					<option value="bhilai">bhilai</option>
					<option value="goa">goa</option>
					<option value="jammu">jammu</option>
					<option value="dharwad">dharwad</option>
					<option value="palakkad">palakkad</option>
				</select><br></div>
				</div>
				<div class="row">
				<div class = "col-25"> <label for="rs2" style="font-size:130%;"><b>Choose Your IIT for 1st:</b></label></div>
				<div class = "col-75">
				<select name="rs2"id="iit"style="font-size:100%" >
				    <option value="madras">madras</option>
					<option value="delhi">delhi</option>
					<option value="bombay">bombay</option>
					<option value="kanpur">kanpur</option>
					<option value="kharagpur">kharagpur</option>
					<option value="roorke">roorke</option>
					<option value="guwahati">guwahati</option>
					<option value="hyderabad">hyderabad</option>
					<option value="indore">indore</option>
					<option value="varanasi">varanasi</option>
					<option value="dhanbad">dhanbad</option>
					<option value="bhuvaneswar">bhuvaneswar</option>
					<option value="gandhinagar">gandhinagar</option>
					<option value="ropar">ropar</option>
					<option value="patna">patna</option>
					<option value="mandi">mandi</option>
					<option value="jhodpur">jhodpur</option>
					<option value="tirupati">tirupati</option>
					<option value="bhilai">bhilai</option>
					<option value="goa">goa</option>
					<option value="jammu">jammu</option>
					<option value="dharwad">dharwad</option>
					<option value="palakkad">palakkad</option>
				</select><br></div>
				</div>
				<div class="clear"></div>
				For Women<br>
				<div class="row">
				<div class = "col-25"> <label for="rs3" style="font-size:130%;"><b>Choose Your IIT for 1st:</b></label></div>
				<div class = "col-75">
				 <select name="rs3"id="iit"style="font-size:100%" >
				    <option value="madras">madras</option>
					<option value="delhi">delhi</option>
					<option value="bombay">bombay</option>
					<option value="kanpur">kanpur</option>
					<option value="kharagpur">kharagpur</option>
					<option value="roorke">roorke</option>
					<option value="guwahati">guwahati</option>
					<option value="hyderabad">hyderabad</option>
					<option value="indore">indore</option>
					<option value="varanasi">varanasi</option>
					<option value="dhanbad">dhanbad</option>
					<option value="bhuvaneswar">bhuvaneswar</option>
					<option value="gandhinagar">gandhinagar</option>
					<option value="ropar">ropar</option>
					<option value="patna">patna</option>
					<option value="mandi">mandi</option>
					<option value="jhodpur">jhodpur</option>
					<option value="tirupati">tirupati</option>
					<option value="bhilai">bhilai</option>
					<option value="goa">goa</option>
					<option value="jammu">jammu</option>
					<option value="dharwad">dharwad</option>
					<option value="palakkad">palakkad</option>
				</select><br></div>
				</div>
				<div class="row">
				<div class = "col-25"> <label for="rs4" style="font-size:130%;"><b>Choose Your IIT for 2nd:</b></label></div>
				<div class = "col-75">
				<select name="rs4"id="iit"style="font-size:100%" >
				    <option value="madras">madras</option>
					<option value="delhi">delhi</option>
					<option value="bombay">bombay</option>
					<option value="kanpur">kanpur</option>
					<option value="kharagpur">kharagpur</option>
					<option value="roorke">roorke</option>
					<option value="guwahati">guwahati</option>
					<option value="hyderabad">hyderabad</option>
					<option value="indore">indore</option>
					<option value="varanasi">varanasi</option>
					<option value="dhanbad">dhanbad</option>
					<option value="bhuvaneswar">bhuvaneswar</option>
					<option value="gandhinagar">gandhinagar</option>
					<option value="ropar">ropar</option>
					<option value="patna">patna</option>
					<option value="mandi">mandi</option>
					<option value="jhodpur">jhodpur</option>
					<option value="tirupati">tirupati</option>
					<option value="bhilai">bhilai</option>
					<option value="goa">goa</option>
					<option value="jammu">jammu</option>
					<option value="dharwad">dharwad</option>
					<option value="palakkad">palakkad</option>
				</select><br></div>
				</div>
				<div class="row">
				<div class = "col-25"> <label for="rs5" style="font-size:130%;"><b>Choose Your IIT for 3rd:</b></label></div>
				<div class = "col-75">
				<select name="rs5"id="iit"style="font-size:100%" >
				    <option value="madras">madras</option>
					<option value="delhi">delhi</option>
					<option value="bombay">bombay</option>
					<option value="kanpur">kanpur</option>
					<option value="kharagpur">kharagpur</option>
					<option value="roorke">roorke</option>
					<option value="guwahati">guwahati</option>
					<option value="hyderabad">hyderabad</option>
					<option value="indore">indore</option>
					<option value="varanasi">varanasi</option>
					<option value="dhanbad">dhanbad</option>
					<option value="bhuvaneswar">bhuvaneswar</option>
					<option value="gandhinagar">gandhinagar</option>
					<option value="ropar">ropar</option>
					<option value="patna">patna</option>
					<option value="mandi">mandi</option>
					<option value="jhodpur">jhodpur</option>
					<option value="tirupati">tirupati</option>
					<option value="bhilai">bhilai</option>
					<option value="goa">goa</option>
					<option value="jammu">jammu</option>
					<option value="dharwad">dharwad</option>
					<option value="palakkad">palakkad</option>
				</select><br></div>
				</div>
				<div class="row">
				<div class = "col-25"> <label for="sport" style="font-size:130%;"><b>Select sport:</b></label></div>
				<div class = "col-75">
				<div class="clear"></div>
				<select name="sport"style="font-size:100%" >
					 <option value="athletics">athletics</option>
					<option value="badminton">badminton</option>
					<option value="cricket">cricket</option>
					<option value="football">football</option>
					<option value="hockey">hockey</option>
					<option value="marchpast">marchpast</option>
					<option value="swimming">swimming</option>
					<option value="volleyball">volleyball</option>
					<option value="weightlifting">weightlifting</option>
				</select><br></div>
				</div>
				<div class="clear"></div>
				<div class="row">
				<div class = "col-25"> <label for="login-id" style="font-size:130%;"><b>Log-Id:</b></label></div>
				<div class = "col-75">
                <input type="text" name="login-id"placeholder="login-id" style="padding-left:5px;width: 150px; height: 30px;font-size: 100%;border-radius:5px;margin:10px;"></div>
				</div>
			
                <input type="submit"name="res"value="Results" style="float:left;width: 500px; height: 30px; font-size: medium;border-radius:5px;">
								
        </form>
		<form action="Home.php",method="POST"style="text-align: center;">
			<input type="submit"name="home"value="Home" style="float:left;width: 500px; height: 30px; font-size: medium;border-radius:5px;">
		</form>
		<form action = "login-page.php" method = "POST"><input type="submit"name="logout" value="Log-Out"
			style="width: 500px; height: 30px; font-size: medium;border-radius:5px;margin-top:0px;"></form>
		</div>
    </body>
</html>