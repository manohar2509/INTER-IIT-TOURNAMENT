<html>
<head>
    <meta charset="UTF-8">
    <title> INTER IIT TOURNAMENT </title>
    <style>
         body 
		{
		background-image:url("background.jpg");
         background-color:#ccccff;       
         margin: 0;
         padding: 0;
         font-family: Helvetica, Arial, sans-serif;
                
		}
		input [type=text],select
{
	height:30px;
	font-size:100%;
	border-radius:5px;
	padding-bottom: 3px;
	padding-left: 3px;
	margin-top:10px;
	border:1px solid black;
}
		input[type=submit] {
		  background-color: #80ff80;
		  border: none;
		  text-decoration: none;
		  margin-top:10px;
		
		}
		input[type=submit]:hover
		{
		  background-color: #eee;
		}
		h1 {
	marginn-top:10px;
	color:white;
  text-shadow: 5px 5px 4px blue;
}
		#wrapper{
			width:310px;
			height:410px;
			border-radius:10px;
			border:5px solid #669999;
			
		}
		.clear 
    {        
        clear:both;         
    }
	.col-25 {
  font-size:medium;
  float: left;
  width: 40%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 60%;
  font-size:medium;
  margin-top: 6px;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
#side1{
	width:50%;
}
#side2{
	width:49.5%;
	position: absolute;
  top: 60px;
  right: 0px;
}
* {
	  box-sizing: border-box;
	}
.side {
  width: 120px;
  height: 50px;
  padding-top:20px;
  background: red;
  text-align:center;
  color: black;
  background-image: linear-gradient(brown, yellow, green);
  font-weight: bold;
  position: relative;
  animation: mymove 5s infinite;
}
div1 {animation-timing-function: cubic-bezier(0,0,1,1);}
#div2 {animation-timing-function: cubic-bezier(0,0.1,0.25,1);}
#div3 {animation-timing-function: cubic-bezier(0,0,1,1);}
#div4 {animation-timing-function: cubic-bezier(0,0,0.58,1);}
#div5 {animation-timing-function: cubic-bezier(0.42,0,0.58,1);}
#div6 {animation-timing-function: cubic-bezier(0,0,0.58,1);}
#div7 {animation-timing-function: cubic-bezier(0.42,0,0.58,1);}
@keyframes mymove {
  from {left: 0px;}
  to {left: 500px;}
}
    </style>

</head>
    <body>
	<div ><h1 style="text-align: center;font-size:250%;"> INTER IIT TOURNAMENT </h1></div>
	<div>
	<div id="side1">
	<div id="div1"class="side"><b>WELCOME</b></div>
	<div id="div2"class="side"><b>COME</b></div>
	<div id="div3"class="side"><b>TO</b></div>
	<div id="div4"class="side"><b>INTER-IIT</b></div>
	<div id="div5"class="side"><b>TOURNAMENT</b></div>
	<div id="div6"class="side"><b>PLEASE-LOGIN</b></div>
	<div id="div7"class="side"><b>HERE</b></div>
	</div>
	<div class="clear"></div>
	<div id="side2">
	<div id="wrapper">
        <form action='p2.php' method='POST'>
		<div class="row">
           <div class = "col-25"> <label for="user" style="font-size:130%;"><b>Username</b></label></div>
           <div class = "col-75"><input type="text" name="user" placeholder="username" style="padding-left:10px;width: 180px; height: 30px; font-size: medium;border-radius:5px;"></div>
		</div>
		<div class="row">
            <div class = "col-25"><label for="pass"style="font-size:130%;"> <b> Password </b></label></div>
            <div class = "col-75"><input type="password" name="pass"placeholder="password"style="padding-left:10px;width: 180px; height: 30px; font-size: medium;border-radius:5px;"></div>
		</div>
                <input type="submit" value="Login" style="width: 300px; height: 30px; font-size: medium;border-radius:5px;"> 
        </form>
		<img src="lgbackground.jpg" width="300px"height="272px">
	</div>
	</div>
</div>
    </body>
</html>