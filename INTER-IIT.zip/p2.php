<html>
<head>
<style>
 body 
		{
		background-image:url("wel.webp.jpg");
		background-position: center; /* Center the image */
		background-repeat: no-repeat; /* Do not repeat the image */
		background-size: 800px 400px;      
         margin: 0;
         padding: 0;
         font-family: Helvetica, Arial, sans-serif;
                
		}
		h1 {
	color: #b32d00;
  text-shadow: 5px 5px 4px blue;
}
		
		input [type=text],select
{
	
	font-size:100%;
	border-radius:5px;
	padding-bottom: 3px;
	padding-left: 3px;
	margin-top:10px;
	border:1px solid black;
}
		input[type=submit] {
		  background-color: #80ff80;
		  border: none;
		  text-decoration: none;
		  margin-top:10px;
		
		}
		input[type=submit]:hover
		{
		  background-color: #eee;
		  width:290px;
		  height:50px;
		}
		label{ 
		font-size:medium;
		float :left;
		}
		* {
	  box-sizing: border-box;
	}
	.pos{
		position:relative;
		top:290px;
		left:470px;
	}
		#div1 {
  width: 100px;
  height: 100px;
  background: red;
  font-size:100%;
  text-align:center;
  padding-top:25px;
  position: relative;
  animation: mymove 10s infinite;
}

@keyframes mymove {
  0%   {top: 0px; left: 250px; background: #99ffff;}
  25%  {top: 0px; left: 900px; background: #66ffcc;}
  50%  {top: 200px; left: 900px; background: yellow;}
  75%  {top: 200px; left: 250px; background: #ff80ff;}
  100% {top: 0px; left: 250px; background: #66ff99;}
}
</style>
</head>
	<h1 style="text-align: center;margin-top:10px;font-size:250%;"> INTER IIT TOURNAMENT </h1>
<?php
$username = $_POST['user'];
$password = $_POST['pass']; 
if ($username && $password) 
{
    if ($username == 'iitdharwad' && $password == 'iitdharwad')
    {   
        ?>
		<div id="div1">Login Successful</div>
		<div class="pos">
            <form action="Home.php" method="POST" style="text-align: center;">

                <input type="submit" value="Go To Main Website" name="from_other"
                    style=" font-size: medium;"> 

            </form>
		</div>
        <?php
    }
    else
    {

        ?>
		<div id="div1">Password or Username Invalid</div>
		<div class="pos">
            <form action="login-page.php" method="POST" style="text-align: center;">
                <input type="submit" value="Click here to go back to Login page" 
                    style=" font-size: medium;"> 

            </form>
		</div>
        <?php
    }
}
else
{
    ?>
	<div id="div1">Please enter username and password</div>
		<div class="pos">
            <form action="login-page.php" method="POST" style="text-align: center;">
                <input type="submit" value="Click here to go back to Login page" 
                    style=" font-size: medium;text-align:center;"> 
            
            </form>
        </div>
        <?php
}
?>
</html>