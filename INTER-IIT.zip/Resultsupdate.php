
  <?php
$host="localhost"; //hostname
$username="root"; //username
$password=""; //password
$con=mysqli_connect("$host", "$username", "$password")or die("cannot connect");
if(isset($_POST['res']))
{
	if($_POST['login-id'] != "")
	{
$database = $_POST['rs'];
$database1 = $_POST['rs1'];
$database2 = $_POST['rs2'];
$sport= $_POST['sport'];
		mysqli_select_db($con,$database);
		$sql ="UPDATE smen SET $sport='10' ";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   mysqli_select_db($con,$database1);
		$sql ="UPDATE smen SET $sport='6'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   mysqli_select_db($con,$database2);
	   $sql ="UPDATE smen SET $sport='2'";
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
$database3 = $_POST['rs3'];
$database4 = $_POST['rs4'];
$database5 = $_POST['rs5'];
$sport= $_POST['sport'];
		mysqli_select_db($con,$database3);
		$sql ="UPDATE swomen SET $sport='10' ";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   mysqli_select_db($con,$database4);
		$sql ="UPDATE swomen SET $sport='6'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   mysqli_select_db($con,$database5);
	   $sql ="UPDATE swomen SET $sport='2'";
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   header('Location: posit.php'); 
		
	}
			else
	{
		?>
				<head>
			<style>
			body 
			{   
			background-image:url("background.jpg");
		      background-color:#ccccff;
              font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
              font-size: 150%;
			}
			input[type=submit] {
			  background-color: #80ff80;
			  border: none;
			  text-decoration: none;
			  border-radius:5px;
			  margin: 4px 2px;
			}
			input[type=submit]:hover
			{
			  background-color: #eee;
			}
			h1 {
	color:white;
  text-shadow: 5px 5px 4px blue;
  font-size:250%;
  
}
			</style>
		</head>
		<h1 style="text-align: center"> INTER IIT TOURNAMENT </h1>
		<p style="text-align: center">Please Enter Your Login-Id!</p>
		<form action="lg1.php",method="POST"style="text-align: center;">
			<input type="submit"name = "rsup"value="Resubmit" style="width: 150px; height: 30px; font-size: medium;"> 
		</form>
		<p style="text-align: center">Go to home!</p>
		<form action="Home.php",method="POST"style="text-align: center;">
			<input type="submit"name="home"value="Home" style="width: 100px; height: 30px; font-size: medium;">
		</form>
		<?php
	}
	}

	?>
	<html>
	<head>
	<style>
	input[type=submit] {
  background-color: #4CAF50;
  border: none;
  text-decoration: none;
  margin: 4px 2px;
}
 input[type=submit]:hover{
		background-color: #eee;
	}
	h1 {
	color:white;
  text-shadow: 5px 5px 4px blue;
  font-size:250%;
  
}
	</style>
	</head>
	</html>