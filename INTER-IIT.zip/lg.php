<html>
<head>
    <meta charset="UTF-8">
    <style>
        body 
        {   background-color:#ccccff;
            font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
            font-size: 150%;
			background-image:url("background.jpg");
        }
		input[type=submit] {
  background-color: #80ff80;
  border: none;
  text-decoration: none;
  margin: 4px 2px;
}
 input[type=submit]:hover{
		background-color: #eee;
	}
input [type=text],select
{
	height:30px;
	width:150px;
	font-size:100%;
	border-radius:5px;
	padding-bottom: 3px;
	padding-left: 3px;
	margin-top:10px;
	border:1px solid black;
}
	#wrapper{
			width:350px;
			height:400px;
			margin:0 auto;
			border:5px solid  #66a3ff;
			border-radius:10px;
		}
		.clear 
    {        
        clear:both;         
    }
	.col-25 {
  font-size:medium;
  float: left;
  width: 40%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 60%;
  font-size:medium;
  margin-top: 6px;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
h1 {
	color:white;
  text-shadow: 5px 5px 4px blue;
  font-size:250%;
}
    </style>
</head>
    <body>
    <h1 style="text-align: center"> INTER IIT TOURNAMENT </h1>
	<div id="wrapper">
        <form action='Accomadation.php' method='POST' style="text-align: center;">
				<div class="row">
				<div class = "col-25"> <label for="IIT" style="font-size:130%;"><b>Choose Your IIT</b></label></div>
				<div class = "col-75">
                <select name="IIT"id="iit" name="IIT"style="font-size:100%" >
				    <option value="madras">madras</option>
					<option value="delhi">delhi</option>
					<option value="bombay">bombay</option>
					<option value="kanpur">kanpur</option>
					<option value="kharagpur">kharagpur</option>
					<option value="roorke">roorke</option>
					<option value="guwahati">guwahati</option>
					<option value="hyderabad">hyderabad</option>
					<option value="indore">indore</option>
					<option value="varanasi">varanasi</option>
					<option value="dhanbad">dhanbad</option>
					<option value="bhuvaneswar">bhuvaneswar</option>
					<option value="gandhinagar">gandhinagar</option>
					<option value="ropar">ropar</option>
					<option value="patna">patna</option>
					<option value="mandi">mandi</option>
					<option value="jhodpur">jhodpur</option>
					<option value="tirupati">tirupati</option>
					<option value="bhilai">bhilai</option>
					<option value="goa">goa</option>
					<option value="jammu">jammu</option>
					<option value="dharwad">dharwad</option>
					<option value="palakkad">palakkad</option>
				</select></div>
				</div>
				<div class="row">
				<div class = "col-25"> <label for="IIT" style="font-size:130%;"><b>LogId</b></label></div>
				<div class = "col-75"><input type="text" name="login-id"placeholder="login-id"style="width: 150px; height: 30px;font-size: 100%;border-radius:5px;padding-left:5px"></div>
                <input type="submit"name = "acc"value="Accomadation" style="width: 350px; height: 30px; font-size: medium;border-radius:5px;"> 
			</form>
			<form action="Home.php",method="POST"style="text-align: center;">
			<input type="submit"name="home"value="Home" style="width: 350px; height: 30px; font-size: medium;border-radius:5px;margin-top:0px;">
			</form>
			<img src="accom.jpg" width="350px"height="177px"style="margin-top:0px">
			<form action = "login-page.php" method = "POST"><input type="submit"name="logout" value="Log-Out"
			style="width: 350px; height: 30px; font-size: medium;border-radius:5px;margin-top:0px;"></form>
			</div>
		</div>
		
    </body>
</html>