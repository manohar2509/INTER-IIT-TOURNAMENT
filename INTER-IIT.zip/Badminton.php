<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
	* {
	  box-sizing: border-box;
	}
	.menu {
	  float:left;
	  width:20%;
	  text-align:center;
	}
	.menu a {
	  background-color:#e5e5e5;
	  padding:8px;
	  margin-top:7px;
	  display:block;
	  width:100%;
	  color:black;
	}
	.main {
	  float:left;
	  width:80%;
	  padding:0 20px;
	  background-image: linear-gradient(blue, yellow, brown);
	}
	.right {
	  background-color:#ccccff;
	  float:left;
	  width:20%;
	  height:500px;
	  padding:15px;
	  margin-bottom:0px;
	  text-align:center;
	}
	.bar{
		background-color:black;
		width:100%;
		height: 50px;
		padding:10px;
		text-align:center;
		margin:0px
	}
    .clear 
    {        
        clear:both;         
    }
	 body 
	{
		background-image:url("background.jpg");
        background-color:#ccccff;    
        margin: 0;
        padding: 0;
        font-family: Helvetica, Arial, sans-serif;
                
    }
	table {
	  width:90%;
	  margin:5px auto;
	  
	}
	table, th, td {
	  border: 1px solid black;
	  border-collapse: collapse;
	}
	.tab{
		width:100%;
		margin:auto;
	}
	
	#Quick-links
	{
		background-image: linear-gradient(blue, yellow, brown);
		height:50px;
	  padding: 5px;
	  text-align: center;
	  background-color: #eee;
	  border: solid 1px #c3c3c3;
	}
	#links
	{
		padding: 50px;
		display: none;
	}

@media only screen and (max-width:620px) {
  /* For mobile phones: */
  .menu, .main, .right {
    width:100%;
  }
}
  input[type=submit]{
  background-color: #80ff80;
  border: none;
  text-decoration: none;
  margin: 4px 2px;
}
 input[type=submit]:hover{
		background-color: #eee;
	}
#top{
		border: 15px solid transparent;
  padding: 15px;
  border-image:url(border.png) 20% round;
	}
@keyframes mymove {
  from {background-color: #33ff33;}
  to {background-color: #bf80ff;}
}
	h1 {
	color:white;
  text-shadow: 5px 5px 4px blue;
  font-size:250%;
  
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script> 
$(document).ready(function(){
  $("#Quick-links").click(function(){
    $("#links").slideToggle("slow");
  });
});
</script>
</head>
<body style="font-family:Verdana;">
<div style="text-align:center";><h1>INTER IIT TOURNAMENT</h1></div>
<div id="top"style="background: red;animation: mymove 4s infinite;padding:15px;text-align:center;">
  <img class = "center"src = "images.jpg" width = "100%" height = "200px">
</div>
<div class = "bar">
	<form action = "Home.php" method = "POST"><input type="submit"name="home" value="Home" style="margin-left:300px;float:left"></form>
	<form action = "Events.php" method = "POST"><input type="submit"name="events"value="Events"style="margin-left:30px;float:left"></form>
	<form action = "lg.php" method = "POST"><input type="submit"name="accomodation" value="Acccomodation"style="margin-left:30px;float:left"></form>
	<form action = "Results.php" method = "POST"><input type="submit"name="results" value="Results"style="margin-left:30px;float:left"></form>
	<form action = "lg2.php" method = "POST"><input type="submit"name="schedule" value="Schedule"style="margin-left:30px;float:left"></form>
	<form action = "Schedule-page.php" method = "POST"><input type="submit"name="schedule-page" value="Schedule-page"style="margin-left:30px;float:left"></form>
	<form action = "Gallery.php" method = "POST"><input type="submit"name="gallery" value="Gallery"style="margin-left:30px;float:left"></form>   
	<form action = "login-page.php" method = "POST"><input type="submit"name="logout" value="Log-Out"style="margin-left:30px;float:left"></form>
</div>
<div class="clear"></div>
<div style="overflow:auto">
  <div class="menu">
    	<div id="Quick-links"><h3>Quick Links</h3></div>
	<div id = "links">
	<ul>
		<li style = "text-align:left"><form action = "Chiefguest.php" method = "POST"><input type="submit" value="Chief Guest"></form></li>
		<li style = "text-align:left"><form action = "Importantdates.php" method = "POST"><input type="submit" value="Important Dates"></form></li>
		<li style = "text-align:left"><form action = "Rules.php" method = "POST"><input type="submit" value="Rules"></form></li>
		<li style = "text-align:left"><form action = "Helpdesk.php" method = "POST"><input type="submit" value="Help Desk"></form></li>
	</ul>
	</div>
  </div>

  <div class="main" >
    <h2 style="text-align: center"> BADMINTON </h2>
<div class="tab">
 <table >
		<tr>
			<th>S.no</th>
			<th>Pool A</th> 
			<th>Pool B</th>
			<th>Pool C</th>
			<th>Pool D</th>
		</tr>
		<tr>
			<td>1</td>
			<td>Madras</td>
			<td>Guwahati</td>
			<td>Gandhinagar</td>
			<td>Bhilai</td>
		</tr>
		<tr>
			<td>2</td>
			<td>Delhi</td>
			<td>Hyderabad</td>
			<td>Ropar</td>
			<td>Goa</td>
			
		</tr>
		<tr>
			<td>3</td>
			<td>Bombay</td>
			<td>Indore</td>
			<td>Patna</td>
			<td>Jammu</td>
		</tr>
		<tr>
			<td>4</td>
			<td>Kanpur</td>
			<td>Varanasi</td>
			<td>Mandi</td>
			<td>Dharwad</td>
		</tr>
		<tr>
			<td>5</td>
			<td>Kharagpur</td>
			<td>Dhanbad</td>
			<td>Jhodpur</td>
			<td>Palakkad</td>
		</tr>
		<tr>
			<td>6</td>
			<td>Roorkee</td>
			<td>Bhuvaneswar</td>
			<td>Tirupati</td>
			<td>-</td>
		</tr>
	</table>
</div>
<div class="tab">
<p style="float:left;padding-left:40px">Date : 10/12/2020</p>
<p style="float:left;padding-left:100px">Timings:8AM-12PM,2PM-5PM</p>
<div class="clear"></div>
 <table >
		<tr>
			<th>S.no</th>
			<th>Match</th> 
			<th>pool</th>
			<th>Section</th>
			<th>Time</th>
		</tr>
		<tr>
			<td>1</td>
			<td>Madras vs Roorkee</td>
			<td>Pool A</td>
			<td>Both(M/W)</td>
			<td>8AM-9AM</td>
		</tr>
		<tr>
			<td>2</td>
			<td>Gandhinagar vs Tirupati</td>
			<td>Pool C</td>
			<td>Both(M/W)</td>
			<td>10AM-11AM</td>
			
		</tr>
		<tr>
			<td>3</td>
			<td>Delhi vs Kharagpur</td>
			<td>Pool A</td>
			<td>Both(M/W)</td>
			<td>11AM-12PM</td>
		</tr>
		<tr>
			<td>4</td>
			<td>Ropar vs Jhodpur</td>
			<td>Pool C</td>
			<td>Both(M/W)</td>
			<td>2PM-3PM</td>
		</tr>
		<tr>
			<td>5</td>
			<td>Bombay vs Kanpur</td>
			<td>Pool A</td>
			<td>Both(M/W)</td>
			<td>3PM-4PM</td>
		</tr>
		<tr>
			<td>6</td>
			<td>Patna vs Mandi</td>
			<td>Pool C</td>
			<td>Both(M/W)</td>
			<td>4PM-5PM</td>
		</tr>
	</table>
</div>
<div class="tab">
<p style="float:left;padding-left:40px">Date : 11/12/2020</p>
<p style="float:left;padding-left:100px">Timings:8AM-12PM,2PM-5PM</p>
<div class="clear"></div>
 <table >
		<tr>
			<th>S.no</th>
			<th>Match</th> 
			<th>pool</th>
			<th>Section</th>
			<th>Time</th>
		</tr>
		<tr>
			<td>1</td>
			<td>Guwahati vs Bhuvaneswar</td>
			<td>Pool B</td>
			<td>Both(M/W)</td>
			<td>8AM-9AM</td>
		</tr>
		<tr>
			<td>2</td>
			<td>Bhilai vs Palakkad</td>
			<td>Pool D</td>
			<td>Both(M/W)</td>
			<td>10AM-11AM</td>
			
		</tr>
		<tr>
			<td>3</td>
			<td>Hyderabad vd Dhanbad</td>
			<td>Pool B</td>
			<td>Both(M/W)</td>
			<td>11AM-12PM</td>
		</tr>
		<tr>
			<td>4</td>
			<td>Goa vs Dharwad</td>
			<td>Pool D</td>
			<td>Both(M/W)</td>
			<td>2PM-3PM</td>
		</tr>
		<tr>
			<td>5</td>
			<td>Indore vs Varanasi</td>
			<td>Pool B</td>
			<td>Both(M/W)</td>
			<td>3PM-4PM</td>
		</tr>
		<tr>
			<td>6</td>
			<td>Jammu vs Bhilai</td>
			<td>Pool D</td>
			<td>Both(M/W)</td>
			<td>4PM-5PM</td>
		</tr>
	</table>
</div>
<div class="tab">
<p style="float:left;padding-left:40px">Date : 13/12/2020</p>
<p style="float:left;padding-left:100px">Timings:8AM-12PM,2PM-5PM</p>
<div class="clear"></div>
	<table>
		<tr>
			<th>S.no</th>
			<th>Match</th> 
			<th>pool</th>
			<th>Section</th>
			<th>Time</th>
		</tr>
		<tr>
			<td>1</td>
			<td>Madras vs Bombay</td>
			<td>Pool A</td>
			<td>Both(M/W)</td>
			<td>8AM-9AM</td>
		</tr>
		<tr>
			<td>2</td>
			<td>Gandhinagar vs Patna</td>
			<td>Pool C</td>
			<td>Both(M/W)</td>
			<td>10AM-11AM</td>
			
		</tr>
		<tr>
			<td>3</td>
			<td>Delhi vs Kanpur</td>
			<td>Pool A</td>
			<td>Both(M/W)</td>
			<td>11AM-12PM</td>
		</tr>
		<tr>
			<td>4</td>
			<td>Ropar vs Mandi</td>
			<td>Pool C</td>
			<td>Both(M/W)</td>
			<td>2PM-3PM</td>
		</tr>
		<tr>
			<td>5</td>
			<td>Kharagpur vs Roorkee</td>
			<td>Pool A</td>
			<td>Both(M/W)</td>
			<td>3PM-4PM</td>
		</tr>
		<tr>
			<td>6</td>
			<td>Jhodpur vs Tirupati</td>
			<td>Pool C</td>
			<td>Both(M/W)</td>
			<td>4PM-5PM</td>
		</tr>
	</table>
  </div>
  <div class="tab">
<p style="float:left;padding-left:40px">Date : 14/12/2020</p>
<p style="float:left;padding-left:100px">Timings:8AM-12PM,2PM-5PM</p>
<div class="clear"></div>
 <table >
		<tr>
			<th>S.no</th>
			<th>Match</th> 
			<th>pool</th>
			<th>Section</th>
			<th>Time</th>
		</tr>
		<tr>
			<td>1</td>
			<td>Guwahati vs Indore</td>
			<td>Pool B</td>
			<td>Both(M/W)</td>
			<td>8AM-9AM</td>
		</tr>
		<tr>
			<td>2</td>
			<td>Goa vs Palakkad</td>
			<td>Pool D</td>
			<td>Both(M/W)</td>
			<td>10AM-11AM</td>
			
		</tr>
		<tr>
			<td>3</td>
			<td>Hyderabad vd Varanasi</td>
			<td>Pool B</td>
			<td>Both(M/W)</td>
			<td>11AM-12PM</td>
		</tr>
		
		<tr>
			<td>4</td>
			<td>Dhanbad vs Bhuvaneswar</td>
			<td>Pool B</td>
			<td>Both(M/W)</td>
			<td>2PM-3PM</td>
		</tr>
	</table>
</div>
<div class="tab">
<p style="float:left;padding-left:40px">Date : 15/12/2020</p>
<p style="float:left;padding-left:100px">Timings:8AM-12PM,2PM-5PM</p>
<div class="clear"></div>
 <table >
		<tr>
			<th>S.no</th>
			<th>Match</th> 
			<th>Winner</th>
			<th>Section</th>
			<th>Time</th>
		</tr>
		<tr>
			<td>1</td>
			<td>A1 vs C1</td>
			<td>W1</td>
			<td>Both(M/W)</td>
			<td>8AM-9AM</td>
		</tr>
		<tr>
			<td>2</td>
			<td>B1 vs D1</td>
			<td>W2</td>
			<td>Both(M/W)</td>
			<td>11AM-12PM</td>
			
		</tr>
		<tr>
			<td>3</td>
			<td>A2 vs C2</td>
			<td>W3</td>
			<td>Both(M/W)</td>
			<td>2PM-3PM</td>
		</tr>
		
		<tr>
			<td>4</td>
			<td>B2 vs D2</td>
			<td>W4</td>
			<td>Both(M/W)</td>
			<td>4PM-5PM</td>
		</tr>
	</table>
</div>
<div class="tab">
<p style="float:left;padding-left:40px">Date : 16/12/2020</p>
<p style="float:left;padding-left:100px">Timings:8AM-12PM,2PM-5PM</p>
<div class="clear"></div>
 <table >
		<tr>
			<th>S.no</th>
			<th>Match</th> 
			<th>Winner</th>
			<th>Section</th>
			<th>Time</th>
		</tr>
		<tr>
			<td>1</td>
			<td>W1 vs W3</td>
			<td>W5</td>
			<td>Both(M/W)</td>
			<td>10AM-11AM</td>
		</tr>
		<tr>
			<td>2</td>
			<td>W2 vs W4</td>
			<td>W6</td>
			<td>Both(M/W)</td>
			<td>2PM-3PM</td>
		</tr>
	</table>
</div>
<div class="tab">
<p style="float:left;padding-left:40px">Date : 17/12/2020</p>
<p style="float:left;padding-left:100px">Timings:8AM-12PM,2PM-5PM</p>
<div class="clear"></div>
	<table>
		<tr>
			<th>S.no</th>
			<th>Match</th> 
			<th>Winner</th>
			<th>Section</th>
			<th>Time</th>
		</tr>
		<tr>
			<td>1</td>
			<td>L5 vs L6</td>
			<td>3rd place</td>
			<td>Both(M/W)</td>
			<td>10AM-11AM</td>
		</tr>
		<tr>
			<td>2</td>
			<td>W5 vs W6</td>
			<td>final</td>
			<td>Both(M/W)</td>
			<td>2PM-3PM</td>
		</tr>
	</table>
  </div>
 </div>

  
</div>

<div style="background-color:#ffb3d1;text-align:center;padding:10px;margin-top:0px;">© copyright IIT Dharwad</div>

</body>
</html>
