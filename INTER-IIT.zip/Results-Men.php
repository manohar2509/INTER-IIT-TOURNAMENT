<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
	* {
	  box-sizing: border-box;
	}
	.menu {
	  float:left;
	  width:20%;
	  text-align:center;
	}
	.menu a {
	  background-color:#e5e5e5;
	  padding:8px;
	  margin-top:7px;
	  display:block;
	  width:100%;
	  color:black;
	}
	.main {
	  float:left;
	  width:80%;
	  padding:0 20px;
	}
	
	.bar{
		background-color:black;
		width:100%;
		height: 50px;
		padding:10px;
		text-align:center;
		margin:0px
	}
    .clear 
    {        
        clear:both;         
    }
	 body 
	{
		background-image:url("background.jpg");
        background-color:#ccccff;        
        margin: 0;
        padding: 0;
        font-family: Helvetica, Arial, sans-serif;
                
    }
	table, th, td {
	  border: 1px solid black;
	  border-collapse: collapse;
	}
	th, td {
	  padding: 15px;
	  text-align: middle;
	}
	#t01 tr:nth-child(even) {
	  background-color: #eee;
	}
	#t01 tr:nth-child(odd) {
	 background-color: #fff;
	}
	#t01 th {
	  background-color: black;
	  color: white;
	}
	#Quick-links
	{
	background-image: linear-gradient(blue, yellow, brown);
	  padding: 5px;
	  height:50px;
	  text-align: center;
	  background-color: #eee;
	  border: solid 1px #c3c3c3;
	}
	#links
	{
		padding: 50px;
		display: none;
	}
	input[type=submit] {
  background-color: #80ff80;
  border: none;
  text-decoration: none;
  margin: 4px 2px;
}
 input[type=submit]:hover{
		background-color: #eee;
	}

@media only screen and (max-width:620px) {
  /* For mobile phones: */
  .menu, .main, .right {
    width:100%;
  }
}
#top{
		border: 15px solid transparent;
  padding: 15px;
  border-image:url(border.png) 20% round;
	}
@keyframes mymove {
  from {background-color: #33ff33;}
  to {background-color: #bf80ff;}
}
	h1 {
	color:white;
  text-shadow: 5px 5px 4px blue;
  font-size:250%;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script> 
$(document).ready(function(){
  $("#Quick-links").click(function(){
    $("#links").slideToggle("slow");
  });
});
</script>
</head>
<body style="font-family:Verdana;">
<div style="text-align:center";><h1>INTER IIT TOURNAMENT</h1></div>
<div id="top"style="background: red;animation: mymove 4s infinite;padding:15px;text-align:center;">
  <img class = "center"src = "images.jpg" width = "100%" height = "200px">
</div>
<div class = "bar">
	<form action = "Home.php" method = "POST"><input type="submit"name="home" value="Home" style="margin-left:300px;float:left"></form>
	<form action = "Events.php" method = "POST"><input type="submit"name="events"value="Events"style="margin-left:30px;float:left"></form>
	<form action = "lg.php" method = "POST"><input type="submit"name="accomodation" value="Acccomodation"style="margin-left:30px;float:left"></form>
	<form action = "Results.php" method = "POST"><input type="submit"name="results" value="Results"style="margin-left:30px;float:left"></form>
	<form action = "Results-Women.php" method = "POST"><input type="submit"name="results" value="Results-Women"style="margin-left:30px;float:left"></form>
	<form action = "lg2.php" method = "POST"><input type="submit"name="schedule" value="Schedule"style="margin-left:30px;float:left"></form>
	<form action = "Gallery.php" method = "POST"><input type="submit"name="gallery" value="Gallery"style="margin-left:30px;float:left"></form> 
    <form action = "login-page.php" method = "POST"><input type="submit"name="logout" value="Log-Out"style="margin-left:30px;float:left"></form>	
</div>
<div class="clear"></div>
<div style="overflow:auto">
  <div class="menu">
    	<div id="Quick-links"><h3>Quick Links</h3></div>
	<div id = "links">
	<ul>
		<li style = "text-align:left"><form action = "Chiefguest.php" method = "POST"><input type="submit" value="Chief Guest"></form></li>
		<li style = "text-align:left"><form action = "Importantdates.php" method = "POST"><input type="submit" value="Important Dates"></form></li>
		<li style = "text-align:left"><form action = "Rules.php" method = "POST"><input type="submit" value="Rules"></form></li>
		<li style = "text-align:left"><form action = "Helpdesk.php" method = "POST"><input type="submit" value="Help Desk"></form></li>
	</ul>
	</div>
  </div>

  <div class="main" >
    <?php
$host="localhost"; //hostname
$username="root"; //username
$password=""; //password
$con=mysqli_connect("$host", "$username", "$password")or die("cannot connect");
?>
    <table class="t1"id="t01">
		<tr >
			<th colspan = "12"style="background-color: #b3cccc"> Men's Event </th>
		</tr>
		<tr>
			<th>Sport/<br>IIT</th>
			<th>athletics</th> 
			<th>badminton</th>
			<th>cricket</th> 
			<th>football</th> 
			<th>hockey</th> 
			<th>marchpast</th> 
			<th>swimming</th> 
			<th>volleyball</th> 
			<th>weightlifting</th>
			<th>totalpoints</th> 
			<th>position</th> 
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'madras');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id = "iit1">madras</td>
			<td id="iit1a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit1b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit1c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit1f"><?php echo "{$row['football']}"?></td>
			<td id="iit1h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit1m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit1s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit1v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit1w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit1t"><?php echo "{$row['t']}"?></td>
			<td id="iit1p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'delhi');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit2">delhi</td>
			<td id="iit2a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit2b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit2c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit2f"><?php echo "{$row['football']}"?></td>
			<td id="iit2h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit2m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit2s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit2v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit2w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit2t"><?php echo "{$row['t']}"?></td>
			<td id="iit2p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'bombay');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit3">bombay</td>
			<td id="iit3a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit3b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit3c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit3f"><?php echo "{$row['football']}"?></td>
			<td id="iit3h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit3m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit3s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit3v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit3w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit3t"><?php echo "{$row['t']}"?></td>
			<td id="iit3p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'kanpur');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit4">kanpur</td>
			<td id="iit4a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit4b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit4c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit4f"><?php echo "{$row['football']}"?></td>
			<td id="iit4h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit4m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit4s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit4v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit4w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit4t"><?php echo "{$row['t']}"?></td>
			<td id="iit4p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'kharagpur');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit5">kharagpur</td>
			<td id="iit5a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit5b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit5c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit5f"><?php echo "{$row['football']}"?></td>
			<td id="iit5h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit5m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit5s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit5v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit5w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit5t"><?php echo "{$row['t']}"?></td>
			<td id="iit5p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'roorkee');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit6">roorkee</td>
			<td id="iit6a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit6b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit6c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit6f"><?php echo "{$row['football']}"?></td>
			<td id="iit6h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit6m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit6s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit6v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit6w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit6t"><?php echo "{$row['t']}"?></td>
			<td id="iit6p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'guwahati');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit7">guwahati</td>
			<td id="iit7a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit7b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit7c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit7f"><?php echo "{$row['football']}"?></td>
			<td id="iit7h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit7m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit7s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit7v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit7w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit7t"><?php echo "{$row['t']}"?></td>
			<td id="iit7p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'hyderabad');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit8">hyderabad</td>
			<td id="iit8a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit8b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit8c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit8f"><?php echo "{$row['football']}"?></td>
			<td id="iit8h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit8m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit8s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit8v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit8w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit8t"><?php echo "{$row['t']}"?></td>
			<td id="iit8p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'indore');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit9">indore</td>
			<td id="iit9a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit9b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit9c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit9f"><?php echo "{$row['football']}"?></td>
			<td id="iit9h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit9m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit9s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit9v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit9w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit9t"><?php echo "{$row['t']}"?></td>
			<td id="iit9p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'varanasi');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit10">varanasi</td>
			<td id="iit10a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit10b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit10c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit10f"><?php echo "{$row['football']}"?></td>
			<td id="iit10h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit10m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit10s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit10v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit10w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit10t"><?php echo "{$row['t']}"?></td>
			<td id="iit10p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr
		<tr>
		<?php
		mysqli_select_db($con,'dhanbad');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit11">dhanbad</td>
			<td id="iit11a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit11b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit11c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit11f"><?php echo "{$row['football']}"?></td>
			<td id="iit11h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit11m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit11s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit11v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit11w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit11t"><?php echo "{$row['t']}"?></td>
			<td id="iit11p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'bhuvaneswar');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit12">bhuvaneswar</td>
			<td id="iit12a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit12b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit12c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit12f"><?php echo "{$row['football']}"?></td>
			<td id="iit12h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit12m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit12s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit12v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit12w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit12t"><?php echo "{$row['t']}"?></td>
			<td id="iit12p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'gandhinagar');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit13">gandhinagar</td>
			<td id="iit13a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit13b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit13c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit13f"><?php echo "{$row['football']}"?></td>
			<td id="iit13h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit13m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit13s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit13v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit13w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit13t"><?php echo "{$row['t']}"?></td>
			<td id="iit13p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'ropar');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit14">ropar</td>
			<td id="iit14a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit14b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit14c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit14f"><?php echo "{$row['football']}"?></td>
			<td id="iit14h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit14m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit14s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit14v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit14w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit14t"><?php echo "{$row['t']}"?></td>
			<td id="iit14p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'patna');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit15">patna</td>
			<td id="iit15a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit15b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit15c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit15f"><?php echo "{$row['football']}"?></td>
			<td id="iit15h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit15m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit15s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit15v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit15w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit15t"><?php echo "{$row['t']}"?></td>
			<td id="iit15p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'jhodpur');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit16">jhodpur</td>
			<td id="iit16a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit16b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit16c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit16f"><?php echo "{$row['football']}"?></td>
			<td id="iit16h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit16m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit16s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit16v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit16w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit16t"><?php echo "{$row['t']}"?></td>
			<td id="iit16p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'mandi');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit17">mandi</td>
			<td id="iit17a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit17b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit17c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit17f"><?php echo "{$row['football']}"?></td>
			<td id="iit17h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit17m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit17s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit17v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit17w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit17t"><?php echo "{$row['t']}"?></td>
			<td id="iit17p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'tirupati');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit18">tirupati</td>
			<td id="iit18a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit18b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit18c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit18f"><?php echo "{$row['football']}"?></td>
			<td id="iit18h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit18m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit18s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit18v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit18w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit18t"><?php echo "{$row['t']}"?></td>
			<td id="iit18p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'bhilai');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit19">bhilai</td>
			<td id="iit19a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit19b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit19c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit19f"><?php echo "{$row['football']}"?></td>
			<td id="iit19h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit19m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit19s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit19v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit19w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit19t"><?php echo "{$row['t']}"?></td>
			<td id="iit19p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'goa');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit20">goa</td>
			<td id="iit20a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit20b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit20c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit20f"><?php echo "{$row['football']}"?></td>
			<td id="iit20h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit20m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit20s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit20v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit20w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit20t"><?php echo "{$row['t']}"?></td>
			<td id="iit20p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'jammu');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit21">jammu</td>
			<td id="iit21a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit21b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit21c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit21f"><?php echo "{$row['football']}"?></td>
			<td id="iit21h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit21m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit21s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit21v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit21w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit21t"><?php echo "{$row['t']}"?></td>
			<td id="iit21p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'dharwad');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit22">dharwad</td>
			<td id="iit22a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit22b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit22c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit22f"><?php echo "{$row['football']}"?></td>
			<td id="iit22h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit22m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit22s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit22v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit22w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit22t"><?php echo "{$row['t']}"?></td>
			<td id="iit22p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
		<tr>
		<?php
		mysqli_select_db($con,'palakkad');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		?>
			<td id="iit23">palakkad</td>
			<td id="iit23a"><?php echo "{$row['athletics']}"?></td>
			<td id="iit23b"><?php echo "{$row['badminton']}"?></td>
			<td id="iit23c"><?php echo "{$row['cricket']}"?></td>
			<td id="iit23f"><?php echo "{$row['football']}"?></td>
			<td id="iit23h"><?php echo "{$row['hockey']}"?></td>
			<td id="iit23m"><?php echo "{$row['marchpast']}"?></td>
			<td id="iit23s"><?php echo "{$row['swimming']}"?></td>
			<td id="iit23v"><?php echo "{$row['volleyball']}"?></td>
			<td id="iit23w"><?php echo "{$row['weightlifting']}"?></td>
			<td id="iit23t"><?php echo "{$row['t']}"?></td>
			<td id="iit23p"><?php echo "{$row['p']}"?></td>
			<?php
		}
		?>
		</tr>
	</table>
  </div>


</div>

<div style="background-color:#ffb3d1;text-align:center;padding:10px;margin-top:0px;">© copyright IIT Dharwad</div>

</body>
</html>
