<?php
$host="localhost"; //hostname
$username="root"; //username
$password=""; //password
$con=mysqli_connect("$host", "$username", "$password")or die("cannot connect");
		mysqli_select_db($con,'madras');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum1 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum1=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE smen SET t='$sum1' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'delhi');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum2 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum2=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum2' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bombay');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum3 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum3=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE smen SET t='$sum3' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'kanpur');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum4 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum4=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE smen SET t='$sum4' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'kharagpur');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum5 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum5=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum5' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'roorkee');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum6 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum6=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum6' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'guwahati');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum7 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum7=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE smen SET t='$sum7' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'hyderabad');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum8 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum8=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE smen SET t='$sum8' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'indore');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum9 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum9=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE smen SET t='$sum9' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'varanasi');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum10 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum10=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE smen SET t='$sum10' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'dhanbad');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum11 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum11=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE smen SET t='$sum11' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bhuvaneswar');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum12 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum12=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum12' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'ghandinagar');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum13 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum13=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE smen SET t='$sum13' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'ropar');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum14 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum14=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum14' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'patna');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum15 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum15=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum15' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'mandi');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum16 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum16=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum16' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'jhodpur');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum17= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum17=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum17' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'tirupati');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum18= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum18=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum18' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bhilai');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum19=0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum19=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum19' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'goa');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum20= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum20=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum20' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'jammu');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum21= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum21=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE smen SET t='$sum21' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'dharwad');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum22= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum22=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE smen SET t='$sum22' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'palakkad');
		$sql = 'SELECT *FROM smen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $sum23= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $sum23=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE smen SET t='$sum23' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'madras');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s1 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s1=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE swomen SET t='$s1' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'delhi');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s2 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s2=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE swomen SET t='$s2' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bombay');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s3 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s3=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s3' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'kanpur');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s4 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s4=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE swomen SET t='$s4' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'kharagpur');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s5 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s5=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE swomen SET t='$s5' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'roorkee');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s6 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s6=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE swomen SET t='$s6' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'guwahati');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s7 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s7=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE swomen SET t='$s7' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'hyderabad');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s8 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s8=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE swomen SET t='$s8' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'indore');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s9 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s9=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
		
		$sql ="UPDATE swomen SET t='$s9' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'varanasi');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s10 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s10=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE swomen SET t='$s10' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'dhanbad');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s11 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s11=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s11' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bhuvaneswar');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s12 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s12=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s12' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'ghandinagar');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s13 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s13=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s13' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'ropar');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s14 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s14=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s14' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'patna');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s15 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s15=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s15' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'mandi');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s16 = 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s16=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s16' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'jhodpur');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s17= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s17=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s17' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'tirupati');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s18= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s18=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s18' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bhilai');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s19=0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s19=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE swomen SET t='$s19' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'goa');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s20= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s20=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}
	
		$sql ="UPDATE swomen SET t='$s20' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'jammu');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s21= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s21=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s21' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'dharwad');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s22= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s22=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s22' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'palakkad');
		$sql = 'SELECT *FROM swomen';
	   $retval = mysqli_query($con,$sql);
	   if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
	   }
	   $s23= 0;
	   while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) 
	    {
		   $s23=$row['athletics'] + $row['badminton'] + $row['cricket'] + $row['football'] + $row['hockey'] + $row['marchpast'] + 
			$row['swimming'] + $row['volleyball'] + $row['weightlifting'];
		}

		$sql ="UPDATE swomen SET t='$s23' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		$men1 = array($sum1,$sum2,$sum3,$sum4,$sum5,$sum6,$sum7,$sum8,$sum9,$sum10,$sum11,$sum12,$sum13,$sum14,$sum15,$sum16,
		$sum17,$sum18,$sum19,$sum20,$sum21,$sum22,$sum23);
		$men2 = array($sum1,$sum2,$sum3,$sum4,$sum5,$sum6,$sum7,$sum8,$sum9,$sum10,$sum11,$sum12,$sum13,$sum14,$sum15,$sum16,
		$sum17,$sum18,$sum19,$sum20,$sum21,$sum22,$sum23);
		$women1 = array($s1,$s2,$s3,$s4,$s5,$s6,$s7,$s8,$s9,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23);
		$women2 = array($s1,$s2,$s3,$s4,$s5,$s6,$s7,$s8,$s9,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23);
		$visited = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		$pos = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		$visited1 = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		$pos1 = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		rsort($men2);
		rsort($women2);
		for($i=0;$i<23;$i++)
		{
			for($j=0;$j<23;$j++)
			{
				if($visited[$j] == 0 && $men1[$j] == $men2[$i])
				{
					$visited[$j] = 1;
					$pos[$j] = $i+1;
					
				}
					
			}
			
		}
		for($i=0;$i<23;$i++)
		{
			for($j=0;$j<23;$j++)
			{
				if($visited1[$j] == 0 && $women1[$j] == $women2[$i])
				{
					$visited1[$j] = 1;
					$pos1[$j] = $i+1;
					
				}
					
			}
			
		}
		mysqli_select_db($con,'madras');
		$sql ="UPDATE smen SET p='$pos[0]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'delhi');
		$sql ="UPDATE smen SET p='$pos[1]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bombay');
		$sql ="UPDATE smen SET p='$pos[2]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'kanpur');
		$sql ="UPDATE smen SET p='$pos[3]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'kharagpur');
		$sql ="UPDATE smen SET p='$pos[4]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'roorkee');
		$sql ="UPDATE smen SET p='$pos[5]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'guwahati');
		$sql ="UPDATE smen SET p='$pos[6]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'hyderabad');
		$sql ="UPDATE smen SET p='$pos[7]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'indore');
		$sql ="UPDATE smen SET p='$pos[8]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'varanasi');
		$sql ="UPDATE smen SET p='$pos[9]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'dhanbad');
		$sql ="UPDATE smen SET p='$pos[10]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}mysqli_select_db($con,'bhuvaneswar');
		$sql ="UPDATE smen SET p='$pos[11]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'gandhinagar');
		$sql ="UPDATE smen SET p='$pos[12]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'ropar');
		$sql ="UPDATE smen SET p='$pos[13]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'patna');
		$sql ="UPDATE smen SET p='$pos[14]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'mandi');
		$sql ="UPDATE smen SET p='$pos[15]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'jhodpur');
		$sql ="UPDATE smen SET p='$pos[16]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'tirupati');
		$sql ="UPDATE smen SET p='$pos[17]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bhilai');
		$sql ="UPDATE smen SET p='$pos[18]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'goa');
		$sql ="UPDATE smen SET p='$pos[19]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'jammu');
		$sql ="UPDATE smen SET p='$pos[20]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'dharwad');
		$sql ="UPDATE smen SET p='$pos[21]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'palakkad');
		$sql ="UPDATE smen SET p='$pos[22]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'madras');
		$sql ="UPDATE swomen SET p='$pos1[0]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'delhi');
		$sql ="UPDATE swomen SET p='$pos1[1]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bombay');
		$sql ="UPDATE swomen SET p='$pos1[2]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'kanpur');
		$sql ="UPDATE swomen SET p='$pos1[3]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'kharagpur');
		$sql ="UPDATE swomen SET p='$pos1[4]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'roorkee');
		$sql ="UPDATE swomen SET p='$pos1[5]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'guwahati');
		$sql ="UPDATE swomen SET p='$pos1[6]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'hyderabad');
		$sql ="UPDATE swomen SET p='$pos1[7]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'indore');
		$sql ="UPDATE swomen SET p='$pos1[8]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'varanasi');
		$sql ="UPDATE swomen SET p='$pos1[9]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'dhanbad');
		$sql ="UPDATE swomen SET p='$pos1[10]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}mysqli_select_db($con,'bhuvaneswar');
		$sql ="UPDATE swomen SET p='$pos1[11]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'gandhinagar');
		$sql ="UPDATE swomen SET p='$pos1[12]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'ropar');
		$sql ="UPDATE swomen SET p='$pos1[13]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'patna');
		$sql ="UPDATE swomen SET p='$pos1[14]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'mandi');
		$sql ="UPDATE swomen SET p='$pos1[15]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'jhodpur');
		$sql ="UPDATE swomen SET p='$pos1[16]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'tirupati');
		$sql ="UPDATE swomen SET p='$pos1[17]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'bhilai');
		$sql ="UPDATE swomen SET p='$pos1[18]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'goa');
		$sql ="UPDATE swomen SET p='$pos1[19]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'jammu');
		$sql ="UPDATE swomen SET p='$pos1[20]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'dharwad');
		$sql ="UPDATE swomen SET p='$pos1[21]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		mysqli_select_db($con,'palakkad');
		$sql ="UPDATE swomen SET p='$pos1[22]' where Id = '1'";
		$retval = mysqli_query($con,$sql);
		if(! $retval ) {
		  die('Could not get data: ' . mysqli_error($con));
		}
		header('Location: Results.php'); 
		
?>