Login Credentials:-
username:-iitdharwad
password:-iitdharwad
Firstly run the db.php file which creates the backend data for all IIT's and this redirect to loginpage
For inner logins we are not given any credentials but they should not be empty
