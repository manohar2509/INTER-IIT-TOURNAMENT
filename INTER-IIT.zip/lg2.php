<html>
<head>
    <meta charset="UTF-8">
    <title> INTER IIT TOURNAMENT </title>
    <style>
        body 
        {   
			background-image:url("background.jpg");
		    background-color:#ccccff;
            font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
            font-size: 150%;
        }
		.clear 
    {        
        clear:both;         
    }

		input[type=submit] {
  background-color: #80ff80;
  border: none;
  text-decoration: none;
  margin: 4px 2px;
}
	input [type=text],select
{
	height:30px;
	width:150px;
	font-size:100%;
	border-radius:5px;
	padding-bottom: 3px;
	padding-left: 3px;
	margin-top:10px;
	border:1px solid black;
}
	#wrapper{
			width:400px;
			height:430px;
			margin:0 auto;
			border:5px solid   #990099;
			border-radius:10px;
			
		}
		.clear 
    {        
        clear:both;         
    }
	.col-25 {
  font-size:medium;
  float: left;
  width: 40%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 60%;
  font-size:medium;
  margin-top: 6px;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
 input[type=submit]:hover{
		background-color: #eee;
	}
	h1 {
	color:white;
  text-shadow: 5px 5px 4px blue;
  font-size:250%;
  
}
    </style>
</head>
    <body>
    <h1 style="text-align: center"> INTER IIT TOURNAMENT </h1>
        <form action='sport-schedule.php' method='POST' style="text-align: center;">
		<div id="wrapper">
				<div class="row">
				<div class = "col-25"> <label for="sd" style="font-size:130%;"><b>Choose Your IIT:</b></label></div>
				<div class = "col-75">
                <select name="sd"id="iit" name="IIT"style="font-size:100%" >
				    <option value="1">madras</option>
					<option value="2">delhi</option>
					<option value="3">bombay</option>
					<option value="4">kanpur</option>
					<option value="5">kharagpur</option>
					<option value="6">roorke</option>
					<option value="7">guwahati</option>
					<option value="8">hyderabad</option>
					<option value="9">indore</option>
					<option value="10">varanasi</option>
					<option value="11">dhanbad</option>
					<option value="12">bhuvaneswar</option>
					<option value="13">gandhinagar</option>
					<option value="14">ropar</option>
					<option value="15`">patna</option>
					<option value="16">mandi</option>
					<option value="17">jhodpur</option>
					<option value="18">tirupati</option>
					<option value="19">bhilai</option>
					<option value="20">goa</option>
					<option value="21">jammu</option>
					<option value="22">dharwad</option>
					<option value="23">palakkad</option>
				</select><br></div>
				</div>
				<div class="row">
				<div class = "col-25"> <label for="sd" style="font-size:130%;"><b>Log-Id:</b></label></div>
				<div class = "col-75">
                <input type="text" name="login-id"placeholder="login-id" style="padding-left:5px;width: 150px; height: 30px;font-size: 100%;border-radius:5px;"></div>
				</div>
                <input type="submit"name="sch"value="View Schedule" style="width: 400px; height: 30px; font-size: medium;border-radius:5px;">
        </form>
		<form action="Home.php",method="POST"style="text-align: center;">
			<input type="submit"name="home"value="Home" style="width: 400px; height: 30px; font-size: medium;border-radius:5px;">
		</form>
		<img src="schedule.jpg" width="400px"height="202px"style="margin-top:0px">
		<form action = "login-page.php" method = "POST"><input type="submit"name="logout" value="Log-Out"
			style="width: 400px; height: 30px; font-size: medium;border-radius:5px;margin-top:0px;"></form>
		</div>
    </body>
</html>