<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
	* {
	  box-sizing: border-box;
	}
	.menu {
	  float:left;
	  width:20%;
	  text-align:center;
	}
	.menu a {
	  background-color:#e5e5e5;
	  padding:8px;
	  margin-top:7px;
	  display:block;
	  width:100%;
	  color:black;
	}
	.main {
	  float:left;
	  width:80%;
	  padding:0 20px;
	  background-color:#ccccff;
	  background-image: linear-gradient(red, yellow, green);
	}
	.tab{
		width:100%;
		margin:auto;
	}
	.bar{
		background-color:black;
		width:100%;
		height: 50px;
		padding:10px;
		text-align:center;
		margin:0px
	}
    .clear 
    {        
        clear:both;         
    }
	 body 
	{
		background-image:url("background.jpg");
        background-color:#ccccff; 
		color:black;
        margin: 0;
        padding: 0;
        font-family: Helvetica, Arial, sans-serif;
		font-color:black;
                
    }
	table {
	  width:90%;
	  margin:5px auto;
	  
	}
	table, th, td {
	  border: 1px solid black;
	  border-collapse: collapse;
	}
	.tab{
		width:100%;
		margin:auto;
	}
	
	#Quick-links
	{
		background-image: linear-gradient(blue, yellow, brown);
		height:50px;
	  padding: 5px;
	  text-align: center;
	  background-color:#c2d6d6;
	  border: solid 1px #c3c3c3;
	}
	#links
	{
		padding: 50px;
		display: none;
		height:100px;
	}

@media only screen and (max-width:620px) {
  /* For mobile phones: */
  .menu, .main, .right {
    width:100%;
  }
}
  input[type=submit]{
  background-color: #80ff80;
  border: none;
  text-decoration: none;
  margin: 4px 2px;
}
 input[type=submit]:hover{
		background-color: #eee;
	}
	#top{
		border: 15px solid transparent;
  padding: 15px;
  border-image:url(border.png) 20% round;
	}
@keyframes mymove {
  from {background-color: #33ff33;}
  to {background-color: #bf80ff;}
}
	h1 {
	color:white;
  text-shadow: 5px 5px 4px blue;
  font-size:250%;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script> 
$(document).ready(function(){
  $("#Quick-links").click(function(){
    $("#links").slideToggle("slow");
  });
});
</script>
</head>
<body style="font-family:Verdana;">
<div style="text-align:center";><h1>INTER IIT TOURNAMENT</h1></div>
<div id="top"style="background: red;animation: mymove 4s infinite;padding:15px;text-align:center;">
  <img class = "center"src = "images.jpg" width = "100%" height = "200px">
</div>
<div class = "bar">
	<form action = "Home.php" method = "POST"><input type="submit"name="home" value="Home" style="margin-left:300px;float:left"></form>
	<form action = "Events.php" method = "POST"><input type="submit"name="events"value="Events"style="margin-left:30px;float:left"></form>
	<form action = "lg.php" method = "POST"><input type="submit"name="accomodation" value="Acccomodation"style="margin-left:30px;float:left"></form>
	<form action = "Results.php" method = "POST"><input type="submit"name="results" value="Results"style="margin-left:30px;float:left"></form>
	<form action = "lg2.php" method = "POST"><input type="submit"name="schedule" value="Schedule"style="margin-left:30px;float:left"></form>
	<form action = "Gallery.php" method = "POST"><input type="submit"name="gallery" value="Gallery"style="margin-left:30px;float:left"></form> 
    <form action = "login-page.php" method = "POST"><input type="submit"name="logout" value="Log-Out"style="margin-left:30px;float:left"></form>	
</div>
<div class="clear"></div>
<div style="overflow:auto">
  <div class="menu">
    	<div id="Quick-links"><h3>Quick Links</h3></div>
	<div id = "links" >
	<ul>
		<li style = "text-align:left"><form action = "Chiefguest.php" method = "POST"><input type="submit" value="Chief Guest"></form></li>
		<li style = "text-align:left"><form action = "Importantdates.php" method = "POST"><input type="submit" value="Important Dates"></form></li>
		<li style = "text-align:left"><form action = "Rules.php" method = "POST"><input type="submit" value="Rules"></form></li>
		<li style = "text-align:left"><form action = "Helpdesk.php" method = "POST"><input type="submit" value="Help Desk"></form></li>
	</ul>
	</div>
  </div>

 <div class="main" >
    <div class="tab">
 <table >
		<tr>
			<th>S.no</th>
			<th>Category</th> 
			<th>Name</th>
			<th>Ph:No</th>
			<th>Email-id</th>
		</tr>
		<tr>
			<td>1</td>
			<td>Medical faculty</td>
			<td>Dr.Langer</td>
			<td>9999999999</td>
			<td>9999999999@iitdh.ac.in</td>
		</tr>
		<tr>
			<td>2</td>
			<td>Registration faculty</td>
			<td>prof.Ramesh</td>
			<td>9999999998</td>
			<td>9999999998@iitdh.ac.in</td>
		</tr>
		<tr>
			<td>3</td>
			<td>Events Shedule faculty</td>
			<td>Mr.Suresh</td>
			<td>9999999997</td>
			<td>9999999997@iitdh.ac.in</td>
		</tr>
		<tr>
			<td>4</td>
			<td>Food faculty</td>
			<td>Mr.Sen</td>
			<td>9999999996</td>
			<td>9999999996@iitdh.ac.in</td>
		</tr>
		<tr>
			<td>5</td>
			<td>Accomodation faculty(men)</td>
			<td>Mr.Ram</td>
			<td>9999999995</td>
			<td>9999999995@iitdh.ac.in</td>
		</tr>
		<tr>
			<td>6</td>
			<td>Accomodation faculty(women)</td>
			<td>Ms.Savitri</td>
			<td>9999999994</td>
			<td>9999999994@iitdh.ac.in</td>
		</tr>
		<tr>
			<td>7</td>
			<td>Registration faculty</td>
			<td>Mr.Tarun</td>
			<td>9999999993</td>
			<td>9999999993@iitdh.ac.in</td>
		</tr>
		<tr>
			<td>8</td>
			<td>Transportation faculty</td>
			<td>Ms.Harini</td>
			<td>9999999992</td>
			<td>9999999992@iitdh.ac.in</td>
		</tr>
		<tr>
			<td>9</td>
			<td>Chief Coordinator</td>
			<td>Mr.Charan</td>
			<td>9999999991</td>
			<td>9999999991@iitdh.ac.in</td>
		</tr>
		<tr>
			<td>10</td>
			<td>Maintainance cordinator</td>
			<td>Mr.Syam</td>
			<td>9999999990</td>
			<td>9999999990@iitdh.ac.in</td>
		</tr>
	</table>
</div> 
</div>

<div style="background-color:#ffb3d1;text-align:center;padding:10px;margin-top:0px;">© copyright IIT Dharwad</div>

</body>
</html>
